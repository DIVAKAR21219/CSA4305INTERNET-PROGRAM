CREATE DATABASE IF NOT EXISTS library_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library_management;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('student','admin') NOT NULL DEFAULT 'student',
 phone VARCHAR(30) DEFAULT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 author VARCHAR(160) NOT NULL,
 isbn VARCHAR(40) DEFAULT NULL,
 category VARCHAR(100) DEFAULT NULL,
 publisher VARCHAR(160) DEFAULT NULL,
 publish_year INT DEFAULT NULL,
 total_copies INT NOT NULL DEFAULT 1,
 available_copies INT NOT NULL DEFAULT 1,
 description TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS borrowings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 book_id INT NOT NULL,
 issue_date DATE NOT NULL,
 due_date DATE NOT NULL,
 return_date DATE DEFAULT NULL,
 fine DECIMAL(10,2) NOT NULL DEFAULT 0,
 status ENUM('issued','returned') NOT NULL DEFAULT 'issued',
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE IF NOT EXISTS materials (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 academic_year VARCHAR(30) NOT NULL,
 semester VARCHAR(30) NOT NULL,
 subject VARCHAR(120) DEFAULT NULL,
 file_name VARCHAR(255) NOT NULL,
 stored_name VARCHAR(255) NOT NULL,
 uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contact_messages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL,
 message TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO books (title,author,isbn,category,publish_year,total_copies,available_copies,description)
SELECT 'Introduction to Algorithms','Thomas H. Cormen','9780262046305','Computer Science',2022,3,3,'A comprehensive introduction to algorithms.'
WHERE NOT EXISTS (SELECT 1 FROM books WHERE title='Introduction to Algorithms');
