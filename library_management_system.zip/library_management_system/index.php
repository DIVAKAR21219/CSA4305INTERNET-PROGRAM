<?php
require_once 'includes.php';
$q=trim($_GET['q']??'');
if($q!==''){$s=$pdo->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ? ORDER BY title");$like="%$q%";$s->execute([$like,$like,$like]);}
else{$s=$pdo->query("SELECT * FROM books ORDER BY title");}
$books=$s->fetchAll(); header_html('Book Catalog');
?>
<section class="hero"><h1>Discover your next great read</h1><p>Search the library catalog, check availability and manage your borrowing.</p>
<form method="get" class="actions"><input style="max-width:520px" name="q" value="<?=e($q)?>" placeholder="Search by book, author or category"><button class="btn">Search books</button></form></section>
<h2>Library catalog</h2><div class="grid">
<?php foreach($books as $b): ?><article class="card"><span class="pill"><?=e($b['category']?:'General')?></span><h3><?=e($b['title'])?></h3><p class="muted">by <?=e($b['author'])?></p><p><?=e(mb_strimwidth($b['description']??'',0,110,'…'))?></p><p><b><?= (int)$b['available_copies'] ?></b> / <?= (int)$b['total_copies'] ?> available</p><a class="btn" href="book.php?id=<?=$b['id']?>">View details</a></article><?php endforeach; ?>
<?php if(!$books): ?><p>No books found. Try another search.</p><?php endif; ?></div>
<?php footer_html(); ?>
