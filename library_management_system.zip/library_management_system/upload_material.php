<?php
require_once 'includes.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_FILES['material'])&&$_FILES['material']['error']===UPLOAD_ERR_OK){
$ext=strtolower(pathinfo($_FILES['material']['name'],PATHINFO_EXTENSION));$allowed=['pdf','doc','docx','ppt','pptx'];
if(!in_array($ext,$allowed,true)||$_FILES['material']['size']>15*1024*1024){flash('File type not allowed or file exceeds 15 MB.');}
else{$dir=__DIR__.'/uploads';if(!is_dir($dir))mkdir($dir,0755,true);$stored=bin2hex(random_bytes(16)).'.'.$ext;
if(move_uploaded_file($_FILES['material']['tmp_name'],$dir.'/'.$stored)){$s=$pdo->prepare('INSERT INTO materials(title,academic_year,semester,subject,file_name,stored_name) VALUES(?,?,?,?,?,?)');$s->execute([trim($_POST['title']),trim($_POST['year']),trim($_POST['semester']),trim($_POST['subject']),basename($_FILES['material']['name']),$stored]);flash('Material uploaded.');}else flash('Upload failed.');}}
header('Location: materials.php');exit;
