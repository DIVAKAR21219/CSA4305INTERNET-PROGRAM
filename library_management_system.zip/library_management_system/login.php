<?php
require_once 'includes.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){$s=$pdo->prepare('SELECT * FROM users WHERE email=?');$s->execute([strtolower(trim($_POST['email']??''))]);$u=$s->fetch();
if($u&&password_verify($_POST['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];header('Location: index.php');exit;}else{$error='Invalid email or password.';}}
header_html('Login');if($error)echo '<div class="error">'.e($error).'</div>';?>
<div class="panel form"><h1>Sign in</h1><form method="post"><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button class="btn">Login</button></form><p>New student? <a href="register.php">Register here</a>.</p></div><?php footer_html(); ?>
