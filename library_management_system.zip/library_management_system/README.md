# Library Management System

A PHP + MySQL library portal with separate Librarian/Admin and Student accounts.

## Requirements
- PHP 8.0+ (PDO enabled)
- MySQL 5.7+ / MariaDB
- Apache (XAMPP/WAMP/LAMP)

## Setup (XAMPP)
1. Copy the `library_management_system` folder into `htdocs`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database.sql`.
4. If needed, edit database settings in `config.php`.
5. Visit `http://localhost/library_management_system/`.
6. Register a student account from the Register link.
7. Create an admin account by registering normally, then run this SQL in phpMyAdmin:
   `UPDATE users SET role='admin' WHERE email='your-email@example.com';`
8. Sign in with the admin account.

## Included features
- Student registration and login
- Role-based admin/student access
- Book search and details
- Admin add, edit and delete books
- Issue and return tracking
- Automatic overdue fine calculation (default ₹5/day)
- Student borrowing history and fine view
- Year/semester-wise study material upload, search and download
- Student profile update
- Contact form (messages saved in database)

## Notes
- Uploaded study materials are stored in `uploads/` and are downloadable only through the logged-in application.
- Change the default fine rate in `config.php`.
- For production deployment, enable HTTPS, configure secure database credentials, add backups, and review server upload limits.
