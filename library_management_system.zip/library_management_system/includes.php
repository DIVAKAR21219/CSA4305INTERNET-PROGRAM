<?php
require_once __DIR__ . '/config.php';

function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return isset($_SESSION['user']); }
function user(): array { return $_SESSION['user'] ?? []; }
function require_login(): void {
    if (!logged_in()) { header('Location: login.php'); exit; }
}
function require_admin(): void {
    require_login();
    if (user()['role'] !== 'admin') { http_response_code(403); exit('Access denied.'); }
}
function flash(string $message): void { $_SESSION['flash'] = $message; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        echo '<div class="notice">'.e($_SESSION['flash']).'</div>';
        unset($_SESSION['flash']);
    }
}
function header_html(string $title='Library Portal'): void { ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?></title><link rel="stylesheet" href="style.css"></head><body>
<header class="top"><a class="brand" href="index.php">📚 Campus Library</a><nav>
<a href="index.php">Books</a><a href="materials.php">Materials</a><a href="contact.php">Contact</a>
<?php if (logged_in()): ?>
<?php if (user()['role']==='admin'): ?><a href="admin.php">Admin</a><?php else: ?><a href="my_books.php">My Borrowing</a><?php endif; ?>
<a href="profile.php">Profile</a><a href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><a class="navbtn" href="register.php">Register</a><?php endif; ?>
</nav></header><main class="container"><?php show_flash(); ?>
<?php }
function footer_html(): void { ?></main><footer>Campus Library Management System · Keep learning</footer></body></html><?php }
