<?php
require_once 'includes.php';require_login();$s=$pdo->prepare('SELECT * FROM materials WHERE id=?');$s->execute([(int)($_GET['id']??0)]);$m=$s->fetch();if(!$m){http_response_code(404);exit('File not found');}$path=__DIR__.'/uploads/'.$m['stored_name'];if(!is_file($path)){http_response_code(404);exit('File is missing');}
header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($m['file_name'])).'"');header('Content-Length: '.filesize($path));readfile($path);exit;
