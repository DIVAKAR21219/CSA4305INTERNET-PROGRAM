<?php
require_once 'includes.php';
$id=(int)($_GET['id']??0);$s=$pdo->prepare('SELECT * FROM books WHERE id=?');$s->execute([$id]);$b=$s->fetch();
if(!$b){http_response_code(404);exit('Book not found');}
header_html($b['title']);
?>
<div class="panel"><a href="index.php">← Back to catalog</a><h1><?=e($b['title'])?></h1><p class="muted">by <?=e($b['author'])?></p>
<p><b>Category:</b> <?=e($b['category'])?></p><p><b>ISBN:</b> <?=e($b['isbn'])?></p><p><b>Publisher:</b> <?=e($b['publisher'])?></p><p><b>Publication year:</b> <?=e($b['publish_year'])?></p>
<p><b>Availability:</b> <?= (int)$b['available_copies'] ?> of <?= (int)$b['total_copies'] ?> copies</p><p><?=nl2br(e($b['description']))?></p>
<?php if(logged_in() && user()['role']==='student' && $b['available_copies']>0): ?><form method="post" action="request_book.php"><input type="hidden" name="book_id" value="<?=$b['id']?>"><button class="btn">Request issue</button></form><?php elseif(!logged_in()): ?><a class="btn" href="login.php">Login to borrow</a><?php endif; ?></div>
<?php footer_html(); ?>
