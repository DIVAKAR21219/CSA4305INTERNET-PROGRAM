<?php
require_once 'includes.php';$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){$name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$body=trim($_POST['message']??'');if($name&&filter_var($email,FILTER_VALIDATE_EMAIL)&&$body){$s=$pdo->prepare('INSERT INTO contact_messages(name,email,message) VALUES(?,?,?)');$s->execute([$name,$email,$body]);$msg='Your message has been submitted.';}else $msg='Please complete all fields with a valid email.';}
header_html('Contact');if($msg)echo '<div class="notice">'.e($msg).'</div>';?>
<div class="panel form"><h1>Contact the library</h1><form method="post"><div class="field"><label>Name</label><input name="name" required></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Message</label><textarea name="message" required></textarea></div><button class="btn">Send message</button></form></div><?php footer_html();?>
