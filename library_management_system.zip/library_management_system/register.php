<?php
require_once 'includes.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$name=trim($_POST['name']??'');$email=strtolower(trim($_POST['email']??''));$pass=$_POST['password']??'';
if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<8){$error='Enter a name, valid email and password of at least 8 characters.';}
else{try{$s=$pdo->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");$s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);flash('Registration successful. Please log in.');header('Location: login.php');exit;}catch(PDOException $e){$error='That email address is already registered.';}}
}
header_html('Register');if($error)echo '<div class="error">'.e($error).'</div>';?>
<div class="panel form"><h1>Student registration</h1><form method="post"><div class="field"><label>Full name</label><input name="name" required></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password (minimum 8 characters)</label><input type="password" name="password" minlength="8" required></div><button class="btn">Create account</button></form></div><?php footer_html(); ?>
