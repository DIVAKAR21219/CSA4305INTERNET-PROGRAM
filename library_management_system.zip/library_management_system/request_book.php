<?php
require_once 'includes.php';require_login();
if(user()['role']!=='student'){header('Location: admin.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){$id=(int)($_POST['book_id']??0);$s=$pdo->prepare("SELECT * FROM books WHERE id=? AND available_copies>0");$s->execute([$id]);$b=$s->fetch();
if($b){$c=$pdo->prepare("SELECT COUNT(*) FROM borrowings WHERE user_id=? AND status='issued'");$c->execute([user()['id']]);if((int)$c->fetchColumn()<5){$pdo->beginTransaction();$pdo->prepare("INSERT INTO borrowings(user_id,book_id,issue_date,due_date) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 14 DAY))")->execute([user()['id'],$id]);$pdo->prepare("UPDATE books SET available_copies=available_copies-1 WHERE id=?")->execute([$id]);$pdo->commit();flash('Book issued successfully. Please return it by the due date.');}else{flash('You already have 5 active books. Return one before borrowing another.');}}else{flash('This book is not currently available.');}}
header('Location: my_books.php');exit;
